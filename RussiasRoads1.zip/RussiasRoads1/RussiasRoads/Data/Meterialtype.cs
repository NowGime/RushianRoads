﻿using System;
using System.Collections.Generic;

namespace RussiasRoads.Data;

public partial class Meterialtype
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;
}
