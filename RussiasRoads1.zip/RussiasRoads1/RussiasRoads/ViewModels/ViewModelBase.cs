﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace RussiasRoads.ViewModels;

public class ViewModelBase : ObservableObject
{
}
