﻿using RussiasRoads.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RussiasRoads.Classes
{
    public static class Help
    {
        public static FinalContext DB = new FinalContext();
    }
}
