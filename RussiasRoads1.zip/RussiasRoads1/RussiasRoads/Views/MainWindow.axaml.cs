﻿using Avalonia.Controls;

namespace RussiasRoads.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
